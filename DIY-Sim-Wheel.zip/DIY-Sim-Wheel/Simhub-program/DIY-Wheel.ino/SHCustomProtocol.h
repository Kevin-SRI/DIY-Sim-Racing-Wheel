#ifndef __SHCUSTOMPROTOCOL_H__
#define __SHCUSTOMPROTOCOL_H__

#include <Arduino.h>
#include <Joystick.h>

class SHCustomProtocol {
private:

int readRotary(int pin) {
    int val = analogRead(pin);
    if      (val < 20)                 return 1;
    else if (val >= 60  && val < 120)  return 2;
    else if (val >= 120 && val < 210)  return 3;
    else if (val >= 210 && val < 310)  return 4;
    else if (val >= 310 && val < 410)  return 5;
    else if (val >= 410 && val < 500)  return 6;
    else if (val >= 500 && val < 600)  return 7;
    else if (val >= 600 && val < 690)  return 8;
    else if (val >= 690 && val < 790)  return 9;
    else if (val >= 790 && val < 890)  return 10;
    else if (val >= 890 && val < 970)  return 11;
    else                               return 12;
}

public:

	/*
	CUSTOM PROTOCOL CLASS
	SEE https://github.com/zegreatclan/SimHub/wiki/Custom-Arduino-hardware-support

	GENERAL RULES :
		- ALWAYS BACKUP THIS FILE, reinstalling/updating SimHub would overwrite it with the default version.
		- Read data AS FAST AS POSSIBLE in the read function
		- NEVER block the arduino (using delay for instance)
		- Make sure the data read in "read()" function READS ALL THE DATA from the serial port matching the custom protocol definition
		- Idle function is called hundreds of times per second, never use it for slow code, arduino performances would fall
		- If you use library suspending interrupts make sure to use it only in the "read" function when ALL data has been read from the serial port.
			It is the only interrupt safe place

	COMMON FUNCTIONS :
		- FlowSerialReadStringUntil('\n')
			Read the incoming data up to the end (\n) won't be included
		- FlowSerialReadStringUntil(';')
			Read the incoming data up to the separator (;) separator won't be included
		- FlowSerialDebugPrintLn(string)
			Send a debug message to simhub which will display in the log panel and log file (only use it when debugging, it would slow down arduino in run conditions)

	*/

	// Called when starting the arduino (setup method in main sketch)
	void setup() {
    Joystick.begin();
	}

	// Called when new data is coming from computer
	void read() {
		// EXAMPLE 1 - read the whole message and sent it back to simhub as debug message
		// Protocol formula can be set in simhub to anything, it will just echo it
		// -------------------------------------------------------
		String message = FlowSerialReadStringUntil('\n');
		FlowSerialDebugPrintLn("Message received : " + message);
	
		/*
		// -------------------------------------------------------
		// EXAMPLE 2 - reads speed and gear from the message
		// Protocol formula must be set in simhub to
		// format([DataCorePlugin.GameData.NewData.SpeedKmh],'0') + ';' + isnull([DataCorePlugin.GameData.NewData.Gear],'N')
		// -------------------------------------------------------

		int speed = FlowSerialReadStringUntil(';').toInt();
		String gear = FlowSerialReadStringUntil('\n');

		FlowSerialDebugPrintLn("Speed : " + String(speed));
		FlowSerialDebugPrintLn("Gear : " + gear);
		*/
	}

	// Called once per arduino loop, timing can't be predicted, 
	// but it's called between each command sent to the arduino
	void loop() {
    int rotary1Position = readRotary(A0);
    int rotary2Position = readRotary(A1);

    // Rotary 1 → buttons 75–86
    // Joystick.setButton() is zero-indexed, so button 75 = index 74
    for (int i = 0; i < 12; i++) {
        Joystick.setButton(74 + i, rotary1Position == i + 1);
    }

    // Rotary 2 → buttons 87–98 → index 86–97
    for (int i = 0; i < 12; i++) {
        Joystick.setButton(86 + i, rotary2Position == i + 1);
    }
  
	}

	// Called once between each byte read on arduino,
	// THIS IS A CRITICAL PATH :
	// AVOID ANY TIME CONSUMING ROUTINES !!!
	// PREFER READ OR LOOP METHOS AS MUCH AS POSSIBLE
	// AVOID ANY INTERRUPTS DISABLE (serial data would be lost!!!)
	void idle() {
	}
};

#endif
